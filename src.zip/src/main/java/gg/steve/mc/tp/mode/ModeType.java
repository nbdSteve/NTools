package gg.steve.mc.tp.mode;

public enum ModeType {
    NONE,
    TOOL,
    SELL;
}
