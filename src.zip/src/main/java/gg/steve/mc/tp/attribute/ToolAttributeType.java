package gg.steve.mc.tp.attribute;

public enum ToolAttributeType {
    USES,
    BLOCKS_MINED,
}